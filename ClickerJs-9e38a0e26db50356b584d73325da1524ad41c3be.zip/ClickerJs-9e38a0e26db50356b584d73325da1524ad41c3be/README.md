# ClickerJs
Simple clicking game to learn [React](https://facebook.github.io/react/)

[Post discussing creation process](http://www.samansari.info/2015/12/relearning-web-development-by-writing.html)

## Installation
Install dependencies using [npm](https://docs.npmjs.com/getting-started/what-is-npm):

    npm install

Build `bundle.js` using:

    npm run build

Then open `index.html` with your browser, or see it live on github at http://elucidation.github.io/ClickerJs
